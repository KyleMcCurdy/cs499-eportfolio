package com.contacts;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Service class that manages Contact objects.
 * Provides methods to add, update, delete, and retrieve contacts.
 */
public class ContactService {

    // Store contacts using a HashMap for fast lookup by ID
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact to the service.
     *
     * @param contact the contact object to add
     * @return the added contact
     * @throws IllegalArgumentException if the contact is null or ID already exists
     */
    public Contact addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        if (contacts.containsKey(contact.getContactId())) {
            throw new IllegalArgumentException("Contact ID already exists");
        }

        contacts.put(contact.getContactId(), contact);
        return contact;
    }

    /**
     * Deletes a contact by its ID.
     *
     * @param contactId the ID of the contact to delete
     * @throws IllegalArgumentException if the ID is null or contact is not found
     */
    public void deleteContact(String contactId) {
        if (contactId == null || contactId.isBlank()) {
            throw new IllegalArgumentException("Contact ID cannot be null or blank");
        }

        if (!contacts.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact not found");
        }

        contacts.remove(contactId);
    }

    /**
     * Updates the details of an existing contact.
     * Only non-null values are updated.
     *
     * @param contactId the ID of the contact to update
     * @param firstName new first name (optional)
     * @param lastName  new last name (optional)
     * @param phone     new phone number (optional)
     * @param address   new address (optional)
     * @return the updated contact
     * @throws IllegalArgumentException if contact ID is null or does not exist
     */
    public Contact updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null || contactId.isBlank()) {
            throw new IllegalArgumentException("Contact ID cannot be null or blank");
        }

        Contact contact = contacts.get(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }

        if (firstName != null && !firstName.isBlank()) {
            contact.setFirstName(firstName);
        }
        if (lastName != null && !lastName.isBlank()) {
            contact.setLastName(lastName);
        }
        if (phone != null && !phone.isBlank()) {
            contact.setPhone(phone);
        }
        if (address != null && !address.isBlank()) {
            contact.setAddress(address);
        }

        return contact;
    }

    /**
     * Retrieves a contact by ID.
     *
     * @param contactId the ID of the contact to retrieve
     * @return the contact object, or null if not found
     */
    public Contact getContact(String contactId) {
        if (contactId == null || contactId.isBlank()) {
            throw new IllegalArgumentException("Contact ID cannot be null or blank");
        }
        return contacts.get(contactId);
    }

    /**
     * Provides a read-only view of all contacts.
     *
     * @return unmodifiable map of contacts
     */
    public Map<String, Contact> getAllContacts() {
        return Collections.unmodifiableMap(contacts);
    }
}
