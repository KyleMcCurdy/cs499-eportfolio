package com.contacts.test;

import static org.junit.jupiter.api.Assertions.*;

import com.contacts.Contact;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the Contact class.
 * 
 * These tests validate that a Contact object is created with valid data,
 * rejects invalid data, and allows safe updates through its setters.
 */
class ContactTest {

    @Test
    void testValidContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");

        assertNotNull(contact, "Contact should be created successfully with valid input");
        assertEquals("12345", contact.getContactId(), "Contact ID should match");
        assertEquals("John", contact.getFirstName(), "First name should match");
        assertEquals("Doe", contact.getLastName(), "Last name should match");
        assertEquals("1234567890", contact.getPhone(), "Phone number should match");
        assertEquals("123 Elm Street", contact.getAddress(), "Address should match");
    }

    @Test
    void testInvalidPhone() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345", "John", "Doe", "12345", "123 Elm Street"),
                "Phone number must be exactly 10 digits");
    }

    @Test
    void testInvalidContactId() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Elm Street"),
                "Contact ID longer than 10 characters should not be allowed");
    }

    @Test
    void testInvalidFirstName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345", "ThisNameIsTooLong", "Doe", "1234567890", "123 Elm Street"),
                "First name longer than 10 characters should not be allowed");
    }

    @Test
    void testInvalidLastName() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345", "John", "ThisLastNameIsTooLong", "1234567890", "123 Elm Street"),
                "Last name longer than 10 characters should not be allowed");
    }

    @Test
    void testInvalidAddress() {
        assertThrows(IllegalArgumentException.class,
                () -> new Contact("12345", "John", "Doe", "1234567890",
                        "This address is way too long and should not be accepted by the system"),
                "Address longer than 30 characters should not be allowed");
    }

    @Test
    void testSettersWorkCorrectly() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");

        contact.setFirstName("Jane");
        contact.setLastName("Smith");
        contact.setPhone("9876543210");
        contact.setAddress("456 Oak Avenue");

        assertEquals("Jane", contact.getFirstName(), "First name should be updated");
        assertEquals("Smith", contact.getLastName(), "Last name should be updated");
        assertEquals("9876543210", contact.getPhone(), "Phone number should be updated");
        assertEquals("456 Oak Avenue", contact.getAddress(), "Address should be updated");
    }

    @Test
    void testSettersRejectInvalidValues() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");

        assertThrows(IllegalArgumentException.class, () -> contact.setFirstName(null),
                "First name cannot be null");
        assertThrows(IllegalArgumentException.class, () -> contact.setLastName("ThisLastNameIsTooLong"),
                "Last name longer than 10 characters should not be allowed");
        assertThrows(IllegalArgumentException.class, () -> contact.setPhone("11122"),
                "Invalid phone number should not be allowed");
        assertThrows(IllegalArgumentException.class, () -> contact.setAddress(null),
                "Address cannot be null");
    }
}
