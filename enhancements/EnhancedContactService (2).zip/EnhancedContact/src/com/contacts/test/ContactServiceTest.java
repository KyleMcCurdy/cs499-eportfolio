package com.contacts.test;

import static org.junit.jupiter.api.Assertions.*;

import com.contacts.Contact;
import com.contacts.ContactService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Unit tests for the ContactService class.
 * 
 * This class uses JUnit 5 to validate that contacts can be added,
 * deleted, updated, and managed correctly by the ContactService.
 */
class ContactServiceTest {

    private ContactService contactService;

    /**
     * Sets up a fresh ContactService before each test.
     */
    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);
        assertNotNull(contactService.getContact("12345"),
                "Contact should be successfully added and retrievable");
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"),
                "Contact should be removed after deletion");
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);
        contactService.updateContact("12345", "Jane", "Doe", "9876543210", "456 Oak Avenue");
        Contact updatedContact = contactService.getContact("12345");

        assertEquals("Jane", updatedContact.getFirstName(), "First name should be updated");
        assertEquals("9876543210", updatedContact.getPhone(), "Phone number should be updated");
        assertEquals("456 Oak Avenue", updatedContact.getAddress(), "Address should be updated");
    }

    @Test
    void testAddDuplicateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Elm Street");
        contactService.addContact(contact);

        assertThrows(IllegalArgumentException.class,
                () -> contactService.addContact(contact),
                "Adding a contact with a duplicate ID should throw an exception");
    }

    @Test
    void testUpdateNonExistentContact() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.updateContact("99999", "Jane", "Smith", "1112223333", "789 Pine Road"),
                "Updating a non-existent contact should throw an exception");
    }

    @Test
    void testDeleteNonExistentContact() {
        assertThrows(IllegalArgumentException.class,
                () -> contactService.deleteContact("99999"),
                "Deleting a non-existent contact should throw an exception");
    }
}
