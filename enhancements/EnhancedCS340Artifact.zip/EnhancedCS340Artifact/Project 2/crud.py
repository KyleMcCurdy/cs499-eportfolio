import pymongo
from pymongo import MongoClient, errors


class AnimalShelterCRUD:
    """CRUD operations for the Animal collection in MongoDB."""

    def __init__(self, username, password, host="localhost", port=27017, db_name="AAC", collection_name="animals", timeout=5000):
        """
        Initialize the database connection.

        :param username: MongoDB username
        :param password: MongoDB password
        :param host: Database host (default localhost)
        :param port: Database port (default 27017)
        :param db_name: Database name
        :param collection_name: Collection name
        :param timeout: Connection timeout in milliseconds
        """
        try:
            # Safe MongoDB connection
            self.client = MongoClient(
                f"mongodb://{username}:{password}@{host}:{port}/",
                serverSelectionTimeoutMS=timeout
            )
            # Force connection check
            self.client.server_info()

            self.database = self.client[db_name]
            self.collection = self.database[collection_name]

        except errors.ServerSelectionTimeoutError as e:
            raise Exception(f"Database connection failed: {e}")

    def create(self, data: dict):
        """
        Insert a document into the collection.
        :param data: Dictionary representing the document
        :return: Inserted document ID
        """
        if isinstance(data, dict) and data:
            try:
                result = self.collection.insert_one(data)
                return result.inserted_id
            except Exception as e:
                raise Exception(f"Insert failed: {e}")
        else:
            raise ValueError("Data must be a non-empty dictionary.")

    def read(self, query: dict = None, projection: dict = None):
        """
        Read documents from the collection.
        :param query: Dictionary filter (default = all documents)
        :param projection: Fields to include/exclude
        :return: List of documents
        """
        try:
            query = query or {}
            return list(self.collection.find(query, projection))
        except Exception as e:
            raise Exception(f"Read failed: {e}")

    def update(self, query: dict, new_values: dict):
        """
        Update document(s) in the collection.
        :param query: Dictionary filter
        :param new_values: Dictionary of fields to update
        :return: Number of modified documents
        """
        if not (isinstance(query, dict) and isinstance(new_values, dict)):
            raise ValueError("Both query and new_values must be dictionaries.")

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            raise Exception(f"Update failed: {e}")

    def delete(self, query: dict):
        """
        Delete document(s) from the collection.
        :param query: Dictionary filter
        :return: Number of deleted documents
        """
        if not isinstance(query, dict):
            raise ValueError("Query must be a dictionary.")

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            raise Exception(f"Delete failed: {e}")

    def __del__(self):
        """Ensure MongoDB client is closed when the object is deleted."""
        if hasattr(self, "client"):
            self.client.close()
