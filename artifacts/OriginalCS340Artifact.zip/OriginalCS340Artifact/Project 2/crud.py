import pymongo
from pymongo import MongoClient

class AnimalShelterCRUD:
    """CRUD operations for Animal collection in MongoDB."""

    def __init__(self, username, password, host, port, db_name, collection_name):
        # Create connection string
        self.client = MongoClient(f"mongodb://{username}:{password}@{host}:{port}/")
        
        # Connect to database and collection
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def create(self, data):
        """Insert a document into the collection."""
        if data is not None:
            result = self.collection.insert_one(data)  # insert and return _id
            return result
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query, projection=None):
        """Read documents from the collection with optional projection."""
        if query is None:
            query = {}
        return list(self.collection.find(query, projection))

    def update(self, query, new_values):
        """Update document(s) in the collection."""
        if query and new_values:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        else:
            raise Exception("Query and new values are required for update.")

    def delete(self, query):
        """Delete document(s) from the collection."""
        if query:
            result = self.collection.delete_many(query)
            return result.deleted_count
        else:
            raise Exception("Query parameter is required for delete.")



